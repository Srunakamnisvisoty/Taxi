package org.example.controller;

import org.example.service.CarService;
import org.example.view.CarView;

public class ControllerCarImpl implements ControllerCar {

    private CarService carService;
    private CarView carView;

    public ControllerCarImpl(CarService carService, CarView carView) {
        this.carService = carService;
        this.carView = carView;
    }

    @Override
    public void addDriverForCar() {
        String[] idArray = carView.addDriver();
        carService.addDriverForCar(idArray[0], idArray[1]);
    }


    @Override
    public void allPrice() {
        carView.allPrice(carService.allPrice());
    }

    @Override
    public void sortCarByFuelConsumption() {
        carService.sortCarByFuelConsumption();
        carView.sortCarByFuelConsumption();
    }


    @Override
    public void findByEquipment() {
        carView.showCarsByParameter(carService.findByEquipment(carView.equipment()));
    }

    @Override
    public void findByFuelConsumption() {
        carView.showCarsByParameter(carService.findByFuelConsumption(carView.findByFuelConsumption()));
    }

    @Override
    public void showAll() {
        carService.deleteDriverFromCar();
        carView.showAll(carService.all());
    }

    @Override
    public void findById() {
        carView.show(carService.findById(carView.findById()));
    }

    @Override
    public void delete() {
        carService.delete(carView.findById());
    }

    @Override
    public void create() {
        carService.add(carView.create());
    }
}
