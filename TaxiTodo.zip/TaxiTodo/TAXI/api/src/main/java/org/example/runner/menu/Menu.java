package org.example.runner.menu;


import org.example.controller.ControllerCar;
import org.example.controller.ControllerCarImpl;
import org.example.controller.ControllerDriver;
import org.example.controller.ControllerDriverImpl;
import org.example.entity.Car;
import org.example.entity.Driver;
import org.example.repository.CarRepositoryImpl;
import org.example.repository.DriverRepositoryImpl;
import org.example.service.CarServiceImpl;
import org.example.service.DriverServiceImpl;
import org.example.view.CarViewImpl;
import org.example.view.DriverViewImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {


    public static void launch() {

        List<Car> carList = new ArrayList<>();
        List<Driver> driverList = new ArrayList<>();
        Scanner scan = new Scanner(System.in);

        ControllerCar controllerCar = new ControllerCarImpl(new CarServiceImpl(
                new CarRepositoryImpl(carList), new DriverRepositoryImpl(driverList)), new CarViewImpl());

        ControllerDriver controllerDriver = new ControllerDriverImpl(new DriverServiceImpl(
                new DriverRepositoryImpl(driverList)), new DriverViewImpl());

        menu();
        int choose = scan.nextInt();
        while (true) {
            if (choose == 4) {
                System.out.println("Выход из приложения");
                break;
            }
            switch (choose) {
                case 1:
                    carMenu();
                    int carChoose = scan.nextInt();
                    while (true) {
                        if (carChoose >= 9) {
                            menu();
                            break;
                        }
                        switch (carChoose) {
                            case 1:
                                controllerCar.create();
                                break;
                            case 2:
                                controllerCar.delete();
                                break;
                            case 3:
                                controllerCar.findById();
                                break;
                            case 4:
                                controllerCar.showAll();
                                break;
                            case 5:
                                controllerCar.findByEquipment();
                                break;
                            case 6:
                                controllerCar.findByFuelConsumption();
                                break;
                            case 7:
                                controllerCar.sortCarByFuelConsumption();
                                break;
                            case 8:
                                controllerCar.addDriverForCar();
                                break;
                        }
                        carMenu();
                        carChoose = scan.nextInt();
                    }
                    break;
                case 2:
                    driverMenu();
                    int driverChoose = scan.nextInt();
                    while (true) {
                        if (driverChoose >= 5) {
                            menu();
                            break;
                        }
                        switch (driverChoose) {
                            case 1:
                                controllerDriver.create();
                                break;
                            case 2:
                                controllerDriver.delete();
                                break;
                            case 3:
                                controllerDriver.findById();
                                break;
                            case 4:
                                controllerDriver.showAll();
                                break;
                        }
                        driverMenu();
                        driverChoose = scan.nextInt();
                    }
                    break;
                case 3:
                    controllerCar.allPrice();
                    menu();
                    break;
            }
            choose = scan.nextInt();
        }
    }


    private static void menu() {
        System.out.println("Главное меню");
        System.out.println("1. Операции с машинами");
        System.out.println("2. Операции с водителями");
        System.out.println("3. Цена таксопарка");
        System.out.println("4. Выход из приложения");
        System.out.println("Сделайте ваш выбор");
    }

    private static void carMenu() {
        System.out.println("1. Добавить машину");
        System.out.println("2. Удалить машину");
        System.out.println("3. Найти машину по id");
        System.out.println("4. Показать список машин");
        System.out.println("5. Найти машины по комплектации");
        System.out.println("6. Найти машины по расходу топлива");
        System.out.println("7. Отсортировать машины по расходу топлива");
        System.out.println("8. Добавить водителя машине");
        System.out.println("9. Выход в главное меню");
        System.out.println("Сделайте ваш выбор");
    }

    private static void driverMenu() {
        System.out.println("1. Добавить водителя");
        System.out.println("2. Уволить водителя");
        System.out.println("3. Найти водлителя по id");
        System.out.println("4. Показать список всех водителей");
        System.out.println("5. Выход в главное меню");
        System.out.println("Сделайте ваш выбор");
    }
}
