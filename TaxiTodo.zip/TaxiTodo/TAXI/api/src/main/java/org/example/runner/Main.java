package org.example.runner;

import org.example.runner.menu.Menu;

public class Main {

    public static void main(String[] args) {

        Menu.launch();
    }
}
