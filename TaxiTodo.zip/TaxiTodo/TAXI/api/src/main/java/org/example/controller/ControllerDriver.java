package org.example.controller;

public interface ControllerDriver extends Controller {
}
