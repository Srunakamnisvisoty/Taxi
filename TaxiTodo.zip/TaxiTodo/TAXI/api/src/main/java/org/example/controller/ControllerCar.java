package org.example.controller;

public interface ControllerCar extends Controller {

    void addDriverForCar();

    void allPrice();

    void sortCarByFuelConsumption();

    void findByEquipment();

    void findByFuelConsumption();

}
