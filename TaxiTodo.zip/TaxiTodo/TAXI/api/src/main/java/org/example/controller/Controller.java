package org.example.controller;

public interface Controller {

    void findById();

    void delete();

    void create();

    void showAll();

}
