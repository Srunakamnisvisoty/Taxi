package org.example.controller;

import org.example.service.DriverService;
import org.example.view.DriverView;

public class ControllerDriverImpl implements ControllerDriver{

    private DriverService driverService;
    private DriverView driverView;

    public ControllerDriverImpl(DriverService driverService, DriverView driverView) {
        this.driverService = driverService;
        this.driverView = driverView;
    }

    @Override
    public void findById() {
        driverView.show(driverService.findById(driverView.findById()));
    }

    @Override
    public void delete() {
        driverService.delete(driverView.findById());

    }

    @Override
    public void create() {
        driverService.add(driverView.create());
    }

    @Override
    public void showAll() {
        driverView.showAll(driverService.all());
    }
}
