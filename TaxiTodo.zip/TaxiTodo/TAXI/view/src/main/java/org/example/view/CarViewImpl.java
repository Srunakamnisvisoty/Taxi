package org.example.view;

import org.example.entity.Car;
import org.example.entity.Driver;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class CarViewImpl implements CarView {


    @Override
    public String findById() {
        System.out.println("Введите id машины: ");
        Scanner id = new Scanner(System.in);
        String idUuid = id.next();
        if (!(idUuid.length() == 36)) {
            System.out.println("Id введён не верно, попробуйте ввести снова");
            idUuid = id.next();
        }
        return idUuid;
    }

    @Override
    public Car create() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите марку машины: ");
        String brand = scanner.next();
        System.out.println("Введите модель машины: ");
        String model = scanner.next();
        System.out.println("Введите коплектацию: ");
        String equipment = scanner.next();
        System.out.println("Введите расход топлива: ");
        int fuelConsumption = scanner.nextInt();
        System.out.println("Введите возвраст машины: ");
        int age = scanner.nextInt();
        System.out.println("Введите цену: ");
        int price = scanner.nextInt();
        return new Car(UUID.randomUUID(), brand, model, equipment, fuelConsumption, age, price);
    }

    @Override
    public void show(Car car) {
        if (car == null) {
            System.out.println("Машина не найдена");
        } else {
            System.out.println(car);
        }
    }

    @Override
    public void showAll(List<Car> list) {
        if (list.size() == 0) {
            System.out.println("В таксопарке нет машин");
        } else {
            System.out.println("Список всех машин: ");
            for (Car car : list) {
                System.out.println(car);
                System.out.println("Список водителей этой машины: ");
                for (Driver driver : car.getDrivers()) {
                    System.out.println(driver + "\n");
                }
            }
        }
    }

    @Override
    public String[] addDriver() {
        String[] idArray = new String[2];
        Scanner idScan = new Scanner(System.in);
        System.out.println("Введите id машины, которой хотите добавить водителя: ");
        idArray[0] = idScan.next();
        if (!(idArray[0].length() == 36)) {
            System.out.println("Id введён не верно, попробуйте ввести снова");
            idArray[0] = idScan.next();
        }
        System.out.println("Введите id водителя, который будет водить машину: ");
        idArray[1] = idScan.next();
        if (!(idArray[1].length() == 36)) {
            System.out.println("Id введён не верно, попробуйте ввести снова");
            idArray[1] = idScan.next();
        }
        return idArray;
    }


    @Override
    public void allPrice(int allPrice) {
        if (allPrice == 0) {
            System.out.println("В таксопарке нет машин");
        } else {
            System.out.println("Цена таксопарка составляет " + allPrice);
        }
    }

    @Override
    public void sortCarByFuelConsumption() {
        System.out.println("Машины отсортированы по расхоу топлива");
    }


    @Override
    public String equipment() {
        System.out.println("Введите комплектацию: ");
        Scanner equipment = new Scanner(System.in);
        return equipment.next();
    }

    @Override
    public void showCarsByParameter(List<Car> carList) {
        if (carList.size() == 0) {
            System.out.println("Нет машин с такими параметроми");
        } else {
            System.out.println("Список машин по заданному параметру: ");
            for (Car car : carList) {
                System.out.println(car);
            }
        }
    }

    @Override
    public int findByFuelConsumption() {
        System.out.println("Введите расход топлива: ");
        Scanner consumption = new Scanner(System.in);
        return consumption.nextInt();
    }
}

