package org.example.view;

import org.example.entity.Driver;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class DriverViewImpl implements DriverView {

//    @Override
//    public void showAllId(List<UUID> idList) {
//        if (idList.size() == 0) {
//            System.out.println("Нет водителей в таксопарке");
//        } else {
//            System.out.println("Список всех id водителей: ");
//            for (UUID id : idList) {
//                System.out.println(id);
//            }
//        }
//    }

    @Override
    public String findById() {
        System.out.println("Введите id водителя: ");
        Scanner uuid = new Scanner(System.in);
        String id = uuid.next();
        if (!(id.length() == 36)) {
            System.out.println("Вы ввели не верный id, попробуйте снова");
            id = uuid.next();
        }
        return id;
    }

    @Override
    public Driver create() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Веввдите имя: ");
        String name = scanner.next();
        System.out.println("Веввдите фамилию: ");
        String lastName = scanner.next();
        System.out.println("Веввдите отчество, если такое имеется: ");
        String middleName = scanner.next();
        System.out.println("Веввдите возраст: ");
        int age = scanner.nextInt();
        System.out.println("Веввдите паспортные данные: ");
        String passportData = scanner.next();
        System.out.println("Веввдите данные водительского удостоверения: ");
        String driversLicense = scanner.next();
        return new Driver(UUID.randomUUID(), name, lastName, middleName, age, passportData, driversLicense);
    }

    @Override
    public void show(Driver driver) {
        if (driver == null) {
            System.out.println("Водитель не найден");
        } else {
            System.out.println(driver);
        }
    }

    @Override
    public void showAll(List<Driver> list) {
        if (list.size() == 0) {
            System.out.println("В атвопарке нет водителей");
        } else {
            System.out.println("Список всех водителей: ");
            for (Driver driver : list) {
                System.out.println(driver);
            }
        }
    }
}
