package org.example.view;

import org.example.entity.Driver;

import java.util.Set;

public interface DriverView extends View<Driver> {
}
