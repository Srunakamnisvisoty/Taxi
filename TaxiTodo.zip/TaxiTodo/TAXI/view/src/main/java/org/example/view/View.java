package org.example.view;

import java.util.List;
import java.util.UUID;

public interface View<T> {

//    void showAllId(List<UUID> list);

    String findById();

    T create();

    void show(T t);

    void showAll(List<T> list);
}
