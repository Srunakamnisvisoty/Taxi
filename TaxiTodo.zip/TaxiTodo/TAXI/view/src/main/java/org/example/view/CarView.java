package org.example.view;

import org.example.entity.Car;

import java.util.List;

public interface CarView extends View<Car> {

    String[] addDriver();

    void allPrice(int allPrice);

    void sortCarByFuelConsumption();

    String equipment();

    void showCarsByParameter(List<Car> carList);

    int findByFuelConsumption();

}
