package org.example.service;

import org.example.entity.Driver;
import org.example.repository.DriverRepository;

import java.util.List;

public class DriverServiceImpl implements DriverService {

    private DriverRepository driverRepository;

    public DriverServiceImpl(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    @Override
    public List<Driver> all() {
        return driverRepository.getAll();
    }

    @Override
    public Driver findById(String id) {
        return driverRepository.get(id);
    }

    @Override
    public void add(Driver driver) {
        driverRepository.create(driver);
    }

    @Override
    public void delete(String id) {
        driverRepository.delete(findById(id));
    }
}
