package org.example.service;

import org.example.entity.Driver;

public interface DriverService extends CrudOperationService<Driver> {
}
