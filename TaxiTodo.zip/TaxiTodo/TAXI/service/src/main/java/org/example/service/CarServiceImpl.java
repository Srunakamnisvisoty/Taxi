package org.example.service;

import org.example.entity.Car;
import org.example.repository.CarRepository;
import org.example.repository.DriverRepository;

import java.util.List;
import java.util.stream.Collectors;

public class CarServiceImpl implements CarService {

    private CarRepository carRepository;
    private DriverRepository driverRepository;

    public CarServiceImpl(CarRepository carRepository, DriverRepository driverRepository) {
        this.carRepository = carRepository;
        this.driverRepository = driverRepository;
    }

    @Override
    public void addDriverForCar(String carId, String driverId) {
        findById(carId).setDrivers(driverRepository.get(driverId));
    }

    @Override
    public List<Car> findByFuelConsumption(int fuelConsumption) {
        return carRepository.getAll().stream().filter(car -> car.getFuelConsumption() == fuelConsumption)
                .collect(Collectors.toList());
    }

    @Override
    public List<Car> findByEquipment(String equipment) {
        return carRepository.getAll().stream().filter(car -> car.getEquipment().equalsIgnoreCase(equipment))
                .collect(Collectors.toList());
    }

    @Override
    public int allPrice() {
        return carRepository.getAll().stream().mapToInt(Car::getPrice).sum();
    }

    @Override
    public void sortCarByFuelConsumption() {
        carRepository.getAll().sort(Car::compareTo);
    }

    @Override
    public List<Car> all() {
        return carRepository.getAll();
    }

    @Override
    public Car findById(String id) {
        return carRepository.get(id);
    }

    @Override
    public void add(Car car) {
        carRepository.create(car);
    }

    @Override
    public void delete(String id) {
        carRepository.delete(findById(id));
    }

    public void deleteDriverFromCar() {
        for (Car car : carRepository.getAll()) {
            car.getDrivers().removeIf(driver -> !driverRepository.getAll().contains(driver));
        }
    }
}