package org.example.service;

import org.example.entity.Car;

import java.util.List;

public interface CarService extends CrudOperationService<Car> {

    void addDriverForCar(String carId, String driverId);

    List<Car> findByFuelConsumption(int fuelConsumption);

    List<Car> findByEquipment(String equipment);

    int allPrice();

    void sortCarByFuelConsumption();

    void deleteDriverFromCar();
}
