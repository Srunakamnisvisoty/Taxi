package org.example.repository;

import org.example.entity.Driver;

public interface DriverRepository extends CrudOperation<Driver> {
}
