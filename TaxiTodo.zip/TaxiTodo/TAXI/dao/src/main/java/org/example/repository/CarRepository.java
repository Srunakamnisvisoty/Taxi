package org.example.repository;

import org.example.entity.Car;
import org.example.entity.Driver;

import java.util.List;
import java.util.Set;

public interface CarRepository extends CrudOperation<Car> {
}
