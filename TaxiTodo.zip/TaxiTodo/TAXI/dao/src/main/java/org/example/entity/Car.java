package org.example.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
public class Car implements Comparable<Car> {

    private UUID id;
    private String brand;
    private String model;
    private String equipment;
    private int fuelConsumption;
    private int age;
    private List<Driver> drivers = new ArrayList<>();
    private int price;

    public Car(UUID id, String brand, String model, String equipment, int fuelConsumption, int age, int price) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.equipment = equipment;
        this.fuelConsumption = fuelConsumption;
        this.age = age;
        this.price = price;
    }


    public void setDrivers(Driver driver) {
        drivers.add(driver);
    }

    @Override
    public String toString() {
        return  "id = " + id +
                " brand = " + brand +
                ", model = " + model +
                ", equipment = " + equipment +
                ", fuelConsumption = " + fuelConsumption +
                ", age = " + age;
    }

    @Override
    public int compareTo(Car car) {
        return fuelConsumption - car.getFuelConsumption();
    }
}
