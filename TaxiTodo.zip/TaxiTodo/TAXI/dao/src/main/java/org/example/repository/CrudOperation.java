package org.example.repository;

import org.example.entity.Car;

import java.util.List;
import java.util.UUID;

public interface CrudOperation<T> {

    List<T> getAll();

    T get(String id);

    void delete(T t);

    void create(T t);
}
