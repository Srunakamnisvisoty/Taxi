package org.example.repository;

import org.example.entity.Driver;

import java.util.List;

public class DriverRepositoryImpl implements DriverRepository {

    private List<Driver> driverList;

    public DriverRepositoryImpl(List<Driver> driverList) {
        this.driverList = driverList;
    }

    @Override
    public List<Driver> getAll() {
        return driverList;
    }

    @Override
    public Driver get(String id) {
        for (Driver driver : driverList) {
            if (driver.getId().toString().equals(id)) {
                return driver;
            }
        }
        return null;
    }

    @Override
    public void delete(Driver driver) {
        driverList.remove(driver);
    }

    @Override
    public void create(Driver driver) {
        driverList.add(driver);
    }
}
