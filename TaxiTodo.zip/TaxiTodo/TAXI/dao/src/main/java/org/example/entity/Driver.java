package org.example.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Setter
@Getter
public class Driver extends PersonData {

    private UUID id;

    public Driver(UUID id, String name, String lastName, String middleName, int age, String passportData, String driversLicense) {
        super(name, lastName, middleName, age, passportData, driversLicense);
        this.id = id;
    }

    @Override
    public String toString() {
        return "id = " + id + super.toString();
    }
}

