package org.example.repository;

import org.example.entity.Car;

import java.util.List;

public class CarRepositoryImpl implements CarRepository {

    private List<Car> carList;

    public CarRepositoryImpl(List<Car> carList) {
        this.carList = carList;
    }

    @Override
    public List<Car> getAll() {
        return carList;
    }

    @Override
    public Car get(String id) {
        for (Car car : carList) {
            if (car.getId().toString().equals(id)) {
                return car;
            }
        }
        return null;
    }

    @Override
    public void delete(Car car) {
        carList.remove(car);
    }

    @Override
    public void create(Car car) {
        carList.add(car);
    }
}

